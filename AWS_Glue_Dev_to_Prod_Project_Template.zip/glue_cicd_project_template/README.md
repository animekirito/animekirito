# AWS Glue Dev-to-Prod CI/CD Template

This package accompanies the complete implementation manual.

## Dev repository files

- `release-jobs.json`: approved Glue job folders to promote.
- `release.py`: assumes the Production role and pushes only approved folders.
- `buildspec.yml`: CodeBuild commands for the Dev release action.

## Prod repository files

- `deployment-jobs.txt`: exact jobs to deploy in the current change.
- `glue_config.py`: converts Glue Studio JSON into CreateJob/UpdateJob input.
- `deploy.py`: uploads scripts and creates or updates selected Glue jobs.
- `buildspec.yml`: CodeBuild commands for the Production deployment.

## Required CodeBuild environment variables

### Dev CodeBuild

- `PROD_RELEASE_ROLE_ARN`
- `PROD_REPOSITORY_NAME`
- `PROD_BRANCH` (optional, defaults to `main`)

### Prod CodeBuild

- `PROD_GLUE_ROLE_ARN`
- `PROD_GLUE_ASSETS_BUCKET`

CodeBuild provides `AWS_REGION` and `AWS_DEFAULT_REGION` automatically.

Replace all angle-bracket placeholders in the IAM policies before use.
