"""Convert AWS Glue Studio source-control JSON into boto3 JobInput fields."""

from __future__ import annotations

import copy
import json
import os
from typing import Any

PROD_ROLE_ARN = os.environ["PROD_GLUE_ROLE_ARN"]
PROD_BUCKET = os.environ["PROD_GLUE_ASSETS_BUCKET"]


def _copy_if_present(
    destination: dict[str, Any],
    source: dict[str, Any],
    source_key: str,
    destination_key: str,
) -> None:
    value = source.get(source_key)
    if value is not None:
        destination[destination_key] = copy.deepcopy(value)


def _normalise_connections(value: Any) -> dict[str, list[str]] | None:
    if value is None:
        return None
    if isinstance(value, list):
        return {"Connections": [str(item) for item in value]}
    if isinstance(value, dict):
        connections = value.get("connections", value.get("Connections"))
        if connections is not None:
            return {"Connections": [str(item) for item in connections]}
    raise ValueError(f"Unsupported connections format: {value!r}")


def _normalise_codegen_nodes(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return copy.deepcopy(value)
    if isinstance(value, str):
        parsed = json.loads(value)
        if not isinstance(parsed, dict):
            raise ValueError("codeGenConfigurationNodes must decode to an object")
        return parsed
    raise ValueError("Unsupported codeGenConfigurationNodes format")


def create_job_input(source: dict[str, Any], job_name: str) -> dict[str, Any]:
    """Build CreateJob/UpdateJob input and override Production-only values."""
    command_source = source.get("command") or {}
    if not command_source.get("name"):
        raise ValueError(f"{job_name}: command.name is missing from the JSON")

    command: dict[str, Any] = {
        "Name": command_source["name"],
        "ScriptLocation": f"s3://{PROD_BUCKET}/scripts/{job_name}.py",
    }
    _copy_if_present(command, command_source, "pythonVersion", "PythonVersion")
    _copy_if_present(command, command_source, "runtime", "Runtime")

    default_arguments = copy.deepcopy(source.get("defaultArguments") or {})
    default_arguments["--spark-event-logs-path"] = (
        f"s3://{PROD_BUCKET}/sparkHistoryLogs/"
    )
    default_arguments["--TempDir"] = f"s3://{PROD_BUCKET}/temporary/"

    job_input: dict[str, Any] = {
        "Role": PROD_ROLE_ARN,
        "Command": command,
        "DefaultArguments": default_arguments,
    }

    direct_fields = {
        "description": "Description",
        "maxRetries": "MaxRetries",
        "timeout": "Timeout",
        "glueVersion": "GlueVersion",
        "executionClass": "ExecutionClass",
        "securityConfiguration": "SecurityConfiguration",
        "jobMode": "JobMode",
        "jobRunQueuingEnabled": "JobRunQueuingEnabled",
        "maintenanceWindow": "MaintenanceWindow",
        "nonOverridableArguments": "NonOverridableArguments",
    }
    for source_key, destination_key in direct_fields.items():
        _copy_if_present(job_input, source, source_key, destination_key)

    execution_property = source.get("executionProperty")
    if execution_property and execution_property.get("maxConcurrentRuns") is not None:
        job_input["ExecutionProperty"] = {
            "MaxConcurrentRuns": execution_property["maxConcurrentRuns"]
        }

    notification_property = source.get("notificationProperty")
    if notification_property:
        delay = notification_property.get(
            "notifyDelayAfter", notification_property.get("NotifyDelayAfter")
        )
        if delay is not None:
            job_input["NotificationProperty"] = {"NotifyDelayAfter": delay}

    connections = _normalise_connections(source.get("connections"))
    if connections:
        job_input["Connections"] = connections

    codegen_nodes = _normalise_codegen_nodes(source.get("codeGenConfigurationNodes"))
    if codegen_nodes:
        job_input["CodeGenConfigurationNodes"] = codegen_nodes

    worker_type = source.get("workerType")
    number_of_workers = source.get("numberOfWorkers")
    max_capacity = source.get("maxCapacity")

    if worker_type is not None or number_of_workers is not None:
        if worker_type is None or number_of_workers is None:
            raise ValueError(
                f"{job_name}: workerType and numberOfWorkers must be supplied together"
            )
        job_input["WorkerType"] = worker_type
        job_input["NumberOfWorkers"] = number_of_workers
    elif max_capacity is not None:
        job_input["MaxCapacity"] = max_capacity
    elif source.get("allocatedCapacity") is not None:
        # allocatedCapacity is deprecated; use it only as a legacy fallback.
        job_input["MaxCapacity"] = source["allocatedCapacity"]

    # SourceControlDetails is intentionally not copied. The Production repository
    # and deployment pipeline are the source of truth for Production.
    return job_input
