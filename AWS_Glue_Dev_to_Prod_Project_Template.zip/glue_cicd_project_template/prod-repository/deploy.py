#!/usr/bin/env python3
"""Create or update only the Glue jobs listed in deployment-jobs.txt."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

from glue_config import PROD_BUCKET, create_job_input

REGION = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
DEPLOYMENT_LIST = Path(os.environ.get("DEPLOYMENT_LIST", "deployment-jobs.txt"))

s3 = boto3.client("s3", region_name=REGION)
glue = boto3.client("glue", region_name=REGION)


def read_jobs() -> list[str]:
    if not DEPLOYMENT_LIST.exists():
        raise FileNotFoundError(f"Deployment list not found: {DEPLOYMENT_LIST}")

    jobs: list[str] = []
    seen: set[str] = set()
    for raw_line in DEPLOYMENT_LIST.read_text(encoding="utf-8").splitlines():
        job = raw_line.strip()
        if not job or job.startswith("#"):
            continue
        if job in seen:
            raise ValueError(f"Duplicate job in deployment list: {job}")
        seen.add(job)
        jobs.append(job)

    if not jobs:
        raise ValueError("No deployable jobs were found in deployment-jobs.txt")
    return jobs


def validate_files(job: str) -> tuple[Path, Path]:
    script = Path(job) / f"{job}.py"
    definition = Path(job) / f"{job}.json"
    missing = [str(path) for path in (script, definition) if not path.exists()]
    if missing:
        raise FileNotFoundError(f"{job}: missing {', '.join(missing)}")
    return script, definition


def job_exists(job: str) -> bool:
    try:
        glue.get_job(JobName=job)
        return True
    except glue.exceptions.EntityNotFoundException:
        return False


def deploy_job(job: str) -> None:
    script, definition = validate_files(job)
    source = json.loads(definition.read_text(encoding="utf-8"))
    job_input = create_job_input(source, job)

    key = f"scripts/{job}.py"
    print(f"Uploading {script} to s3://{PROD_BUCKET}/{key}", flush=True)
    s3.upload_file(str(script), PROD_BUCKET, key)

    if job_exists(job):
        glue.update_job(JobName=job, JobUpdate=job_input)
        print(f"UPDATED: {job}", flush=True)
    else:
        glue.create_job(Name=job, **job_input)
        print(f"CREATED: {job}", flush=True)


def main() -> int:
    jobs = read_jobs()
    failures: list[str] = []

    for job in jobs:
        try:
            deploy_job(job)
        except (ClientError, ValueError, FileNotFoundError, json.JSONDecodeError) as exc:
            failures.append(job)
            print(f"FAILED: {job}: {exc}", file=sys.stderr, flush=True)

    if failures:
        raise RuntimeError(f"Deployment failed for: {', '.join(failures)}")

    print(f"Production deployment completed for {len(jobs)} job(s).", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
