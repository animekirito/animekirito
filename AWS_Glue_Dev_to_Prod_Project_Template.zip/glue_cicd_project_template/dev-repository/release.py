#!/usr/bin/env python3
"""Promote selected Glue job folders from Dev to the Prod CodeCommit repo."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Sequence

import boto3

REGION = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
PROD_ROLE_ARN = os.environ["PROD_RELEASE_ROLE_ARN"]
PROD_REPOSITORY_NAME = os.environ.get("PROD_REPOSITORY_NAME", "glue-production")
PROD_BRANCH = os.environ.get("PROD_BRANCH", "main")
MANIFEST_FILE = Path(os.environ.get("RELEASE_MANIFEST", "release-jobs.json"))
WORK_DIR = Path("/tmp/glue-production")
REPO_URL = (
    f"https://git-codecommit.{REGION}.amazonaws.com/v1/repos/"
    f"{PROD_REPOSITORY_NAME}"
)


def run(
    command: Sequence[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Run a command and print it without exposing credentials."""
    print("$", " ".join(command), flush=True)
    result = subprocess.run(
        list(command),
        cwd=str(cwd) if cwd else None,
        env=env,
        text=True,
        check=False,
    )
    if check and result.returncode != 0:
        raise RuntimeError(
            f"Command failed with exit code {result.returncode}: {' '.join(command)}"
        )
    return result


def load_manifest() -> tuple[str, str, list[str]]:
    if not MANIFEST_FILE.exists():
        raise FileNotFoundError(f"Release manifest not found: {MANIFEST_FILE}")

    manifest = json.loads(MANIFEST_FILE.read_text(encoding="utf-8"))
    release = str(manifest.get("release", "unversioned"))
    description = str(manifest.get("description", "")).strip()
    jobs = manifest.get("jobs")

    if not isinstance(jobs, list) or not jobs:
        raise ValueError("release-jobs.json must contain a non-empty 'jobs' array")

    clean_jobs: list[str] = []
    seen: set[str] = set()
    for raw_job in jobs:
        job = str(raw_job).strip()
        if not job or job.startswith("#"):
            continue
        if job in seen:
            raise ValueError(f"Duplicate job in release manifest: {job}")
        seen.add(job)
        clean_jobs.append(job)

    if not clean_jobs:
        raise ValueError("No valid job names were found in release-jobs.json")

    return release, description, clean_jobs


def validate_job_folder(job: str) -> None:
    folder = Path(job)
    required = [folder, folder / f"{job}.py", folder / f"{job}.json"]
    missing = [str(item) for item in required if not item.exists()]
    if missing:
        raise FileNotFoundError(
            f"Job '{job}' is incomplete. Missing: {', '.join(missing)}"
        )


def assumed_role_environment() -> dict[str, str]:
    credentials = boto3.client("sts", region_name=REGION).assume_role(
        RoleArn=PROD_ROLE_ARN,
        RoleSessionName="GlueReleaseCodeBuild",
    )["Credentials"]

    environment = os.environ.copy()
    environment.update(
        {
            "HOME": "/tmp",
            "AWS_REGION": REGION,
            "AWS_DEFAULT_REGION": REGION,
            "AWS_ACCESS_KEY_ID": credentials["AccessKeyId"],
            "AWS_SECRET_ACCESS_KEY": credentials["SecretAccessKey"],
            "AWS_SESSION_TOKEN": credentials["SessionToken"],
        }
    )
    return environment


def configure_git(environment: dict[str, str]) -> None:
    commands = [
        ["git", "config", "--global", "credential.helper", "!aws codecommit credential-helper $@"],
        ["git", "config", "--global", "credential.UseHttpPath", "true"],
        ["git", "config", "--global", "user.name", "Glue Release Pipeline"],
        ["git", "config", "--global", "user.email", "glue-release@example.invalid"],
        ["git", "config", "--global", "init.defaultBranch", PROD_BRANCH],
    ]
    for command in commands:
        run(command, env=environment)


def prepare_repository(environment: dict[str, str]) -> None:
    shutil.rmtree(WORK_DIR, ignore_errors=True)
    run(["git", "clone", REPO_URL, str(WORK_DIR)], env=environment)

    remote_branch = run(
        ["git", "ls-remote", "--exit-code", "--heads", "origin", PROD_BRANCH],
        cwd=WORK_DIR,
        env=environment,
        check=False,
    )

    if remote_branch.returncode == 0:
        run(["git", "fetch", "origin", PROD_BRANCH], cwd=WORK_DIR, env=environment)
        run(
            ["git", "checkout", "-B", PROD_BRANCH, f"origin/{PROD_BRANCH}"],
            cwd=WORK_DIR,
            env=environment,
        )
    else:
        run(["git", "checkout", "-B", PROD_BRANCH], cwd=WORK_DIR, env=environment)


def copy_jobs(jobs: list[str]) -> None:
    for job in jobs:
        target = WORK_DIR / job
        shutil.rmtree(target, ignore_errors=True)
        shutil.copytree(Path(job), target)
        print(f"Prepared job folder: {job}", flush=True)


def commit_and_push(
    release: str,
    description: str,
    environment: dict[str, str],
) -> None:
    run(["git", "add", "--all"], cwd=WORK_DIR, env=environment)
    unchanged = run(
        ["git", "diff", "--cached", "--quiet"],
        cwd=WORK_DIR,
        env=environment,
        check=False,
    )
    if unchanged.returncode == 0:
        print("No differences were found. Nothing was pushed.", flush=True)
        return

    message = f"Glue release {release}"
    if description:
        message += f" - {description}"

    run(["git", "commit", "-m", message], cwd=WORK_DIR, env=environment)
    run(
        ["git", "push", "-u", "origin", f"HEAD:{PROD_BRANCH}"],
        cwd=WORK_DIR,
        env=environment,
    )


def main() -> int:
    release, description, jobs = load_manifest()
    for job in jobs:
        validate_job_folder(job)

    environment = assumed_role_environment()
    configure_git(environment)
    prepare_repository(environment)
    copy_jobs(jobs)
    commit_and_push(release, description, environment)
    shutil.rmtree(WORK_DIR, ignore_errors=True)
    print(f"Release {release} completed successfully.", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # CodeBuild should fail with a clear message.
        print(f"ERROR: {exc}", file=sys.stderr, flush=True)
        raise
